const firebaseConfig = {
   apiKey: "AIzaSyD7rkMV5PjEIRTF_OGsSitPdFePmcdQvok",
   authDomain: "netfkix-119db.firebaseapp.com",
   projectId: "netfkix-119db",
   storageBucket: "netfkix-119db.appspot.com",
   messagingSenderId: "646961374314",
   appId: "1:646961374314:web:e7f2a287900e666f5d5613"
  };